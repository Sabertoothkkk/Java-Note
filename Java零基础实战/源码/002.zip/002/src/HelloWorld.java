public class HelloWorld {
	public static void main(String[] args) {
		//1.开辟内存空间
		long num1;
		//2.给变量赋值
		num1 = 10000000000l;
		int num2 = 200;
		System.out.println(num1+num2);
		System.out.println(0.03);
	}
}