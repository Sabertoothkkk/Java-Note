
public class Test {
	public static void main(String[] args) {
		//描述一个用户的基本信息
		//编号、姓名、性别、身高、体重
		int id = 1;
		String name = "张三";
		char gender = '男';
		int height = 175;
		double weight = 60.5;
		System.out.println("用户的基本信息：");
		System.out.println("编号："+id);
		System.out.println("姓名："+name);
		System.out.println("性别："+gender);
		System.out.println("身高："+height);
		System.out.println("体重："+weight);
	}
}
