
public class Test {
	public static void main(String[] args) {
		//1、创建变量用来记录张三的体重
		double weight1 = 70.5;
		//2、创建变量表示李四的体重
		double weight2 = 60.5;
		System.out.println("交换之前：张三的体重是"+weight1+",李四的体重是"+weight2);
		System.out.println("进行交换");
		double temp = weight1;
		weight1 = weight2;
		weight2 = temp;
		System.out.println("交换之后：张三的体重是"+weight1+",李四的体重是"+weight2);
	}
}
