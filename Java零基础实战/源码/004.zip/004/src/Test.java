
public class Test {
	public static void main(String[] args) {
		int score = 90;
		System.out.println("本次答题的得分是："+score);
		String str = score>80? "恭喜您获得优惠券一张":"很遗憾您没有中奖";
		System.out.println(str);
	}
}
