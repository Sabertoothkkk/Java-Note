
public class Test3 {
	public static void main(String[] args) {
		int score = 70;
		int integal = 500;
		System.out.println("本次答题得分："+score);
		System.out.println("您的积分："+integal);
		if((score>60 || integal>=500) && (score>80 || integal>=300)) {
			System.out.println("恭喜您中奖了");
		} else {
			System.out.println("很遗憾");
		}
	}
}
