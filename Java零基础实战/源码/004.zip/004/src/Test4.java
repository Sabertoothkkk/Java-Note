
public class Test4 {
	public static void main(String[] args) {
		int height = 180;
		if(height < 173) {
			System.out.println("M码");
		}else {
			if(height >= 173 & height <= 178) {
				System.out.println("L码");
			}
			if(height>178) {
				System.out.println("XL码");
			}
		}	
	}
}
