
public class Test {
	public static void main(String[] args) {
		int num = 60;
//		if(num == 10) {
//			System.out.println("1");
//		}
//		if(num == 20) {
//			System.out.println("2");
//		}
		switch(num) {
			case 10:
				System.out.println("1");
				break;
			case 20:
				System.out.println("2");
				break;
			case 30:
				System.out.println("3");
				break;
			case 40:
				System.out.println("4");
				break;
			default:
				System.out.println("0");
				break;
		}
	}
}
