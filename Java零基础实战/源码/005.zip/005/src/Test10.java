
public class Test10 {
	public static void main(String[] args) {
		//while循环
//		int num = 0;
//		while(num <= 10) {
//			if(num%2!=0) {
//				System.out.println(num);
//			}
//			num++;
//		}
		//do-while循环
//		int num = 0;
//		do {
//			if(num%2!=0) {
//				System.out.println(num);
//			}
//			num++;
//		}while(num <= 10);
		//for循环
		for(int num = 0;num <= 10;num++) {
			if(num%2!=0) {
				System.out.println(num);
			}
		}
	}
}
