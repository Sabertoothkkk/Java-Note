
public class Test2 {
	public static void main(String[] args) {
		int placing = 1;
		if(placing == 1) {
			System.out.println("奖励2000元");
		}else {
			if(placing == 2) {
				System.out.println("奖励1000元");
			}else {
				if(placing == 3) {
					System.out.println("奖励500元");
				}else{
					System.out.println("没有奖励");
				}
			}
		}
		
		switch(placing) {
			case 1:
				System.out.println("奖励2000元");
				break;
			case 2:
				System.out.println("奖励1000元");
				break;
			case 3:
				System.out.println("奖励500元");
				break;
			default:
				System.out.println("没有奖励");
				break;
		}
	}
}
