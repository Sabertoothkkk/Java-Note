
public class Test4 {
	public static void main(String[] args) {
		//初始化循环变量
		int num = 0;
		//循环条件
		while(num < 10) {
			//循环体
			System.out.println("Hello World");
			//更新循环变量
			num++;
		}
	}
}
