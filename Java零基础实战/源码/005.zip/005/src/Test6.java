import java.util.Scanner;

public class Test6 {
	public static void main(String[] args) {
		String flag = "y";
		do {
			System.out.print("请输入学生学号：");
			Scanner scanner = new Scanner(System.in);
			int id = scanner.nextInt();
			switch(id) {
			case 1:
				System.out.println("张三的成绩是96");
				break;
			case 2:
				System.out.println("李四的成绩是91");
				break;
			case 3:
				System.out.println("王五的成绩是89");
				break;
			default:
				System.out.println("请输入正确的学号");
				break;
			}
			System.out.print("是否继续？y/n");
			flag = scanner.next();
		}while(flag.equals("y"));
		System.out.println("感谢使用学生成绩查询系统");
	}
}
