import java.util.Scanner;

public class Test7 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String result = "";
		do {
			System.out.println("张三参加体能测试，跑1000米");
			System.out.print("是否合格？y/n");
			result = scanner.next();
		}while(result.equals("n"));
		System.out.println("合格，通过测试");
	}
}
