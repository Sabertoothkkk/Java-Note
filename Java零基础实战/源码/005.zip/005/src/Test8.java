import java.util.Scanner;

public class Test8 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
//		String result = "n";
//		while(result.equals("n")) {
//			System.out.println("张三参加体能测试，跑1000米");
//			System.out.print("是否合格？y/n");
//			result = scanner.next();
//		}
//		System.out.println("合格，通过测试");
		String result = "n";
		for(;result.equals("n");) {
			System.out.println("张三参加体能测试，跑1000米");
			System.out.print("是否合格？y/n");
			result = scanner.next();
		}
		System.out.println("合格，通过测试");
	}
}
