import java.util.Arrays;

public class Test {
	public static void main(String[] args) {
		//声明数组
		int[] array;
		//分配内存空间
		array = new int[6];
		//给数组赋值
		array[0] = 1;
		array[1] = 2;
		array[2] = 3;
		array[3] = 4;
		array[4] = 5;
		array[5] = 6;
		System.out.println("数组中的第三个元素是："+array[2]);
	}
}
