
public class Test2 {
	public static void main(String[] args) {
		int[] array = new int[4];
		array[0] = 179;
		array[1] = 182;
		array[2] = 167;
		array[3] = 178;
		double sum = 0;
		for(int i = 0;i < array.length;i++) {
			sum = sum + array[i];
		}
		System.out.println(sum/array.length);
	}
}
