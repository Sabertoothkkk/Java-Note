
public class Test3 {
	public static void main(String[] args) {
		int[] array = {1,2,3,4,5,6};
		System.out.println(array[6]);
		int[] array2 = new int[]{1,2,3,4,5,6};
	}
}
