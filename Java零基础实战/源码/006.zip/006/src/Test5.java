
public class Test5 {
	public static void main(String[] args) {
		int[] array = {73,80,62,93,96,87};
		int max = array[0];
		for(int i = 1;i < array.length;i++) {
			if(array[i] > max) {
				max = array[i];
			}
		}
		System.out.println("数组的最大值是"+max);
		
		int min = array[0];
		for(int i = 1;i < array.length;i++) {
			if(array[i] < min) {
				min = array[i];
			}
		}
		System.out.println("数组的最小值是"+min);
	}
}
