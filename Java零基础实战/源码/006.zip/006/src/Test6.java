import java.util.Arrays;

public class Test6 {
	public static void main(String[] args) {
		int[] array = {96,93,87,80,73,62};
		System.out.println(Arrays.toString(array));
		//将83插入到数组下标为3的位置
		array[3] = 83;
		System.out.println(Arrays.toString(array));
	}
}
