import java.util.Arrays;

public class Test7 {
	public static void main(String[] args) {
		int[] array = {96,93,87,80,73,62};
		int num = 83;
		//将83插入到数组中下标为3的位置
		int[] array2 = new int[array.length+1];
		//将原数组中的数据移动到新数组中
		for(int i=0;i<3;i++) {
			array2[i] = array[i];
		}
		for(int i = 4;i<array2.length;i++) {
			array2[i] = array[i-1];
		}
		array2[3] = 83;
		System.out.println("添加新元素之前的数组："+Arrays.toString(array));
		System.out.println("添加新元素之后的数组："+Arrays.toString(array2));
	}
}
