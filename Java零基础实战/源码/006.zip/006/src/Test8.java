
public class Test8 {
	public static void main(String[] args) {
		int[] array = {73,80,62,93,96,87};
		
	}
}
