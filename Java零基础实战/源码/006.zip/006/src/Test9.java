import java.util.Arrays;

public class Test9 {
	public static void main(String[] args) {
		int[] array = {96,93,87,83,73,62};
		for(int i = 0;i<array.length-1-0;i++) {
			if(array[i] > array[i+1]) {
				int temp = array[i];
				array[i] = array[i+1];
				array[i+1] = temp;
			}
		}
		System.out.println(Arrays.toString(array));
		
		for(int i=0;i<array.length-1-1;i++) {
			if(array[i] > array[i+1]) {
				int temp = array[i];
				array[i] = array[i+1];
				array[i+1] = temp;
			}
		}
		System.out.println(Arrays.toString(array));
		
		for(int i = 0; i < array.length-1-2;i++) {
			if(array[i] > array[i+1]) {
				int temp = array[i];
				array[i] = array[i+1];
				array[i+1] = temp;
			}
		}
		System.out.println(Arrays.toString(array));
		
		for(int i = 0; i < array.length-4;i++) {
			if(array[i] > array[i+1]) {
				int temp = array[i];
				array[i] = array[i+1];
				array[i+1] = temp;
			}
		}
		System.out.println(Arrays.toString(array));
		
		for(int i = 0; i < array.length-5;i++) {
			if(array[i] > array[i+1]) {
				int temp = array[i];
				array[i] = array[i+1];
				array[i+1] = temp;
			}
		}
		System.out.println(Arrays.toString(array));
	}
}
