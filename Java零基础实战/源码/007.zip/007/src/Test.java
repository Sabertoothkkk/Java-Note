import java.util.Arrays;

public class Test {
	public static void main(String[] args) {
		int[] array = {73,80,62,93,96,87};
		int[] array2 = {73,80,62,93,96,87};
		int[] array3 = {66,55,44,33,22};
		System.out.println(Arrays.equals(array, array2));
		System.out.println(Arrays.equals(array2, array3));
//		Arrays.sort(array);
		System.out.println(Arrays.toString(array));
		Arrays.fill(array2, 66);
		System.out.println(Arrays.toString(array2));
//		System.out.println(Arrays.toString(array2));
		int[] copyArray = Arrays.copyOf(array3, 3);
		System.out.println(Arrays.toString(copyArray));
		int index = Arrays.binarySearch(array, 87);
		System.out.println(index);
	}
}
