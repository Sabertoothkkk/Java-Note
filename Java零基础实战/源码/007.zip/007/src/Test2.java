import java.util.Arrays;

public class Test2 {
	public static void main(String[] args) {
		//声明
		int[][] array;
		//开辟内存空间
		array = new int[2][3];
		//赋值
//		array[0][0] = 50;
//		array[0][1] = 60;
//		array[0][2] = 70;
//		array[1][0] = 80;
//		array[1][1] = 90;
//		array[1][2] = 100;
//		System.out.println(Arrays.toString(array));
//		int[] item = {50,60,70};
//		int[] item2 = {80,90,100};
//		array[0] = item;
//		array[1] = item2;
		int[][] array2 = {{50,60,70},{80,90,100,200,300,400,500}};
		String str = "";
		for(int i=0;i<array2.length;i++) {
			for(int j=0;j<array2[i].length;j++) {
				System.out.println(array2[i][j]);
			}
		}
		System.out.println(str);
	}
}
