import java.util.Scanner;

public class Test4 {
	public static void main(String[] args) {
		//初始化用户数据(用户名、年龄、状态)
		String[] names = {"张三","李四","王五","小明"};
		int[] ages = {22,23,20,22};
		String[] states = {"正常","正常","正常","正常",};
		System.out.println("------欢迎使用用户管理系统------");
		System.out.println("1.查询用户");
		System.out.println("2.添加用户");
		System.out.println("3.删除用户");
		System.out.println("4.账号冻结");
		System.out.println("5.账号解封");
		System.out.println("6.退出系统");
		System.out.print("请选择：");
		Scanner scanner = new Scanner(System.in);
		int num = scanner.nextInt();
		switch (num) {
		case 1:
			System.out.println("执行查询用户操作");
			break;
		case 2:
			System.out.println("执行添加用户操作");
			break;
		case 3:
			System.out.println("执行删除用户操作");
			break;
		case 4:
			System.out.println("执行账号冻结操作");
			break;
		case 5:
			System.out.println("执行账号解封操作");
			break;
		case 6:
			System.out.println("执行退出系统操作");
			break;
		default:
			break;
		}
	}
}
