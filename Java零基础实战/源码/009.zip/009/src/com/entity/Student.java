package com.entity;

public class Student {
	public int id;
	public String name;
	
	public Student() {
//		this(3,"王五");
		this.run();
	}
	
	public Student(int id,String name) {
//		this.id = id;
//		this.name = name;
//		this();
	}
	
	public void run() {
		//System.out.println("学生跑步");
		//this();
	}
	
	public void test() {
		this.run();
	}
}
