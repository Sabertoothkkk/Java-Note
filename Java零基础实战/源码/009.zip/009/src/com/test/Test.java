package com.test;
import com.entity.Student;

public class Test {
	public static void main(String[] args) {
		//先创建对象，调用无参构造
		Student student = new Student();
//		//再给对象的属性赋值
//		student.id = 1;
//		student.name = "张三";
		System.out.println(student.id);
		System.out.println(student.name);
		
		//边创建边赋值，调用有参构造,实参
		Student student2 = new Student(2,"李四");
		System.out.println(student2.id);
		System.out.println(student2.name);
	}
}
