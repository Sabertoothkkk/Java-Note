
public class Student {
	private static int id;
	private String name;
	private int age;
	
	static {
		id++;
		System.out.println("执行了Student类的静态代码块");
	}
	
	public static void show() {
		System.out.println("学生信息如下：");
//		System.out.println("学生编号："+id);
//		System.out.println("学生姓名："+name);
//		System.out.println("学生年龄："+age);
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		if(age <= 0) {
			System.out.println("输入的数值有误！");
			age = 18;
		}
		this.age = age;
	}
}
