public class Test {
	String num;
	
	public void show() {
		int num;
		System.out.println(this.num);
	}
	
	public static void main(String[] args) {
		Student student = new Student();
		student.show();
//		Student.show();
		//Student student = new Student();
//		student.setId(1);
//		student.setName("张三");
//		student.setAge(-20);
		//student.show();
//		System.out.println(student.getAge());
	}
}
