
public class Test2 {
	private static int id;
	public static void main(String[] args) {
//		Test2 test = null;
//		for(int i=0;i<10;i++) {
//			test = new Test2();
//			test.id++;
//		}
//		System.out.println(test.id);
		Student stu1 = new Student();
		stu1.setName("张三");
		Student stu2 = new Student();
		stu2.setName("李四");
		Student stu3 = new Student();
		stu3.setName("王五");
		System.out.println(stu1.getId());
		System.out.println(stu2.getId());
		System.out.println(stu3.getId());
	}
	
	
	
}
