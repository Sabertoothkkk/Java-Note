package test;

public class Teacher extends People {
//	public void show() {
//		System.out.println("输出老师信息");
//	}
}
