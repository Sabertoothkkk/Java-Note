package test;

public class User {
	private int id;
	public void test() {
		id++;
	}
}
