package test2;

import test.User;
import test.Teacher;

public class Test {
	public static void main(String[] args) {
		Student student = new Student(1);
		student.show();
		Teacher teacher = new Teacher();
//		teacher.show();
	}
}
