package com.southwind.test;

public class Cashier {
	private Member memeber;
	
	public Member getMemeber() {
		return memeber;
	}

	public void setMemeber(Member memeber) {
		this.memeber = memeber;
	}

	public void settlement() {
		this.memeber.buyBook();
	}
	
	public Member getMember(String name) {
		if(name.equals("ordinary")) {
			return new OrdinaryMember();
		}else {
			return new SuperMember();
		}
	}
}
