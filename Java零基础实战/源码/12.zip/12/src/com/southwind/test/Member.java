package com.southwind.test;

public abstract class Member {
	public abstract void buyBook();
}
