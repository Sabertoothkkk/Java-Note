package com.southwind.test;

public class OrdinaryMember extends Member {
	public void buyBook() {
		System.out.println("普通会员买书打9折");
	}
}
