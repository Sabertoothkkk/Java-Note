package com.southwind.test;

public class SuperMember extends Member {

	@Override
	public void buyBook() {
		// TODO Auto-generated method stub
		
	}
}
