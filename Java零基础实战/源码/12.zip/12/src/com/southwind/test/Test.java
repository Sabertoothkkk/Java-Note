package com.southwind.test;

public class Test {
	public static void main(String[] args) {
//		OrdinaryMember ordinaryMember = new OrdinaryMember();
//		SuperMember superMember = new SuperMember();
//		Cashier cashier = new Cashier();
//		cashier.setMemeber(superMember);
//		cashier.settlement();
//		Memeber memeber = new SuperMember();
		
//		Cashier cashier = new Cashier();
//		OrdinaryMember ordinaryMember = new OrdinaryMember();
//		cashier.settlement(ordinaryMember);
		
		OrdinaryMember ordinaryMember = new OrdinaryMember();
		SuperMember superMember = new SuperMember();
		Cashier cashier = new Cashier();
		cashier.setMemeber(superMember);
		cashier.settlement();
	}
}
