package com.southwind.entity;

public class People {
	private Integer id;
	private String name;
	private Double score;
	
	
	
	public People(Integer id, String name, Double score) {
		super();
		this.id = id;
		this.name = name;
		this.score = score;
	}

	

	@Override
	public String toString() {
		return "People [id=" + id + ", name=" + name + ", score=" + score + "]";
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		People people = (People)obj;
		if(this.id == people.id && this.name.equals(people.name) && this.score.equals(people.score)) {
			return true;
		}
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return (int) (id*name.hashCode()*score);
	}

	public void test() throws CloneNotSupportedException, InterruptedException {
		hashCode();
		getClass();
		equals(null);
		clone();
		toString();
		notify();
		notifyAll();
		wait();
		wait(1000L);
		wait(1000L, 100);
	}
}
