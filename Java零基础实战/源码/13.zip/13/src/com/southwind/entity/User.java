package com.southwind.entity;

public class User{

}
