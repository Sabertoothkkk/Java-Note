package com.southwind.test;

import java.util.ArrayList;
import java.util.List;

import com.southwind.entity.People;

public class Test {
	public static void main(String[] args) {
//		People people = new People(1,"张三",99.0);
//		People people2 = new People(1, "张三", 99.0);
//		System.out.println(people.hashCode());
//		System.out.println(people2.hashCode());
		List<String> list = new ArrayList();
		list.add("Hello");
		list.add("World");
		list.add("Java");
		System.out.println(list);
		List<Integer> list2 = new ArrayList();
		Integer num = null;
		
	}
}
