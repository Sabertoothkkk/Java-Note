package com.southwind.test;

public class Test2 {
	public static void main(String[] args) {
//		byte b = 1;
//		Byte byt = new Byte(b);
//		short s = 2;
//		Short shor = new Short(s);
//		int i = 3;
//		Integer integer = new Integer(i);
//		long l = 4;
//		Long lon = new Long(l);
//		float f = 5.5f;
//		Float flo = new Float(f);
//		double d = 6.6;
//		Double dou = new Double(d);
//		char cha = 'J';
//		Character charac = new Character(cha);
//		boolean bo = true;
//		Boolean bool = new Boolean(bo);
//		System.out.println(byt);
//		System.out.println(shor);
//		System.out.println(integer);
//		System.out.println(lon);
//		System.out.println(flo);
//		System.out.println(dou);
//		System.out.println(charac);
//		System.out.println(bool);
		Byte byt = new Byte("1");
		Short shor = new Short("2");
		Integer integer = new Integer("3");
		Long lon = new Long("4");
		Float flo = new Float("5.5f");
		Double dou = new Double("6.6");
		Character charac = new Character('J');
		Boolean bool = new Boolean("abc");
		System.out.println(byt);
		System.out.println(shor);
		System.out.println(integer);
		System.out.println(lon);
		System.out.println(flo);
		System.out.println(dou);
		System.out.println(charac);
		System.out.println(bool);
	}
}
