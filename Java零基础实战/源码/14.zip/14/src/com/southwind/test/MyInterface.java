package com.southwind.test;

public interface MyInterface {
	public int ID = 0;
	String NAME = "张三";
	public void fly();
}
