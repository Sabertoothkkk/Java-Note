package com.southwind.test;

public interface MyInterface2 {
	public void run();
}
