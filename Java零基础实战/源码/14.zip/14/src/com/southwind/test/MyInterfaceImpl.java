package com.southwind.test;

public class MyInterfaceImpl implements MyInterface,MyInterface2 {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("实现了跑步的方法");
	}

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		System.out.println("实现了飞行的方法");
	}

}
