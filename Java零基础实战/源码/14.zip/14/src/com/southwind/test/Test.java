package com.southwind.test;

import java.util.ArrayList;
import java.util.List;

public class Test {
	public static void main(String[] args) {
		MyInterfaceImpl myInterfaceImpl = new MyInterfaceImpl();
		myInterfaceImpl.fly();
		myInterfaceImpl.run();
	}
}
