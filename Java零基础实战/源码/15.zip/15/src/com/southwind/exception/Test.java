package com.southwind.exception;

public class Test {
	public static void main(String[] args) {
		try {
			int num = 10/0;
			num++;
		}catch (Exception e) {
			// TODO: handle exception
			if(e.getMessage().equals("/ by zero")) {
				System.err.println("分母不能为0");
			}
		}
		System.out.println("finally...");
	}
}
