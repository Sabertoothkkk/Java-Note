package com.southwind.exception;

public class Test2 {
	public static void main(String[] args) {
		System.out.println(test());
	}
	public static int test() {
		try {
			System.out.println("try...");
			return 10;
		}catch (Exception e) {
			// TODO: handle exception
		}finally {
			System.out.println("finally...");
			return 20;
		}
	}
}
