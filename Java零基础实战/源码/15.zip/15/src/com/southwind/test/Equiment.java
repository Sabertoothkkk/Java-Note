package com.southwind.test;

public interface Equiment {
	public void work();
}
