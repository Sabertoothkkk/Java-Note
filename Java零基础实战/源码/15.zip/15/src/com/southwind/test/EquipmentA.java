package com.southwind.test;

public class EquipmentA implements Equiment {
	public void work() {
		System.out.println("设备A运行，生产产品A");
	}
}
