package com.southwind.test;

public class EquipmentB implements Equiment {
	public void work() {
		System.out.println("设备B运行，生产产品B");
	}
}
