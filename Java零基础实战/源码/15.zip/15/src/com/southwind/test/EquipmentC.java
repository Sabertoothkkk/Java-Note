package com.southwind.test;

public class EquipmentC implements Equiment {
	public void work() {
		// TODO Auto-generated method stub
		System.out.println("设备C运行，生产产品C");
	}
	
}
