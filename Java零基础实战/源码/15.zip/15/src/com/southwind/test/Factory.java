package com.southwind.test;

public class Factory {
	private Equiment equipment;

	public Equiment getEquipment() {
		return equipment;
	}

	public void setEquipment(Equiment equipment) {
		this.equipment = equipment;
	}
	
	public void work() {
		System.out.println("开始生产...");
		this.equipment.work();
	}
}
