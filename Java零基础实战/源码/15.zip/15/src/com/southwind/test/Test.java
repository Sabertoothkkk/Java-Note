package com.southwind.test;

public class Test {
	public static void main(String[] args) {
		//初始化工厂
		Factory factory = new Factory();
//		EquipmentB equipmentB = new EquipmentB();
//		factory.setEquipment(equipmentB);
//		EquipmentA equipmentA = new EquipmentA();
//		factory.setEquipment(equipmentA);
		EquipmentC equipmentC = new EquipmentC();
		factory.setEquipment(equipmentC);
		//开始工作
		factory.work();
	}
}
