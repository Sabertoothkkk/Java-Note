package com.southwind.test;

public class Student {
	public void test() {
		
	}
}
