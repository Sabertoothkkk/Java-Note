package com.southwind.test;

import java.lang.reflect.Method;

public class Test {
	public static void main(String[] args) throws Exception {
		test("123");
	}
	
	public static void test(String str) throws Exception {
		int num = Integer.parseInt(str);
	}
	
}
