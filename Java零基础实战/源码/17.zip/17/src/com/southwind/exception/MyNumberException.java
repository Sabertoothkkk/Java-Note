package com.southwind.exception;

public class MyNumberException extends RuntimeException {
	public MyNumberException(String error) {
		super(error);
	}
}
