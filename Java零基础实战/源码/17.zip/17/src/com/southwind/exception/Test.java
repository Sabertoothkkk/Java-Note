package com.southwind.exception;

public class Test {
	public static void main(String[] args){
		Test test = new Test();
		System.out.println(test.add("a"));
	}
	
	public int add(Object object){
		if(object instanceof Integer) {
			int num = (int)object;
			return ++num;
		}else {
			String error = "传入的参数不是整数类型";
			MyNumberException myNumberException = new MyNumberException(error);
			throw myNumberException;
		}
	}
}
