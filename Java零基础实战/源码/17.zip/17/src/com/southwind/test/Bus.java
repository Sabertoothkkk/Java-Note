package com.southwind.test;

public class Bus extends Car {

	public Bus(String name, String color) {
		super(name, color);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String seatNum() {
		// TODO Auto-generated method stub
		return "53座";
	}

}
