package com.southwind.test;

public class CarException extends Exception {
	public CarException(String error) {
		super(error);
	}
}
