package com.southwind.test;

public interface Container {
	public int getweight();
}
