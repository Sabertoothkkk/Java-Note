package com.southwind.test;

public class Sedan extends Car {

	public Sedan(String name, String color) {
		super(name, color);
	}

	@Override
	public String seatNum() {
		// TODO Auto-generated method stub
		return "4座";
	}
	
}
