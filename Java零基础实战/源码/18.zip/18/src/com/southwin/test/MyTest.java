package com.southwin.test;

public class MyTest {
	public void test() {
		for(int i=0;i<10;i++) {
			System.out.println("---MyTest---");
		}
	}
}
