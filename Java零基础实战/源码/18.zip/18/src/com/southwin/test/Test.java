package com.southwin.test;

public class Test {
	/**
	 * 主线程
	 * @param args
	 */
	public static void main(String[] args) {
		//开启子线程
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				for(int i = 0; i < 1000;i++) {
					System.out.println("------李四炒菜-----");
				}
			}
		}).start();
		
		//开启子线程
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				for(int i = 0;i < 1000; i++) {
					System.out.println("王五炒菜=========");
				}
			}
		}).start();
		
		for(int i=0;i<1000;i++) {
			System.out.println("+++++++++张三炒菜");
		}
	}
}
