package com.southwind.test;

public class MyRunnable2 implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<1000;i++) {
			System.out.println("MyRunnable2!!!!!!!!!!!!!!!!!!!!");
		}
	}

}
