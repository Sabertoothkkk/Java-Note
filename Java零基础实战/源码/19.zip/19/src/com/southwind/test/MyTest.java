package com.southwind.test;

public class MyTest {
	public void run() {
		System.out.println("--test--");
	}
}
