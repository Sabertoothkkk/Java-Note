package com.southwind.test;

public class MyThread extends Thread {
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		//定义业务逻辑
		for(int i = 0;i<1000;i++) {
			System.out.println("-------------MyThread");
		}
	}
	
}
