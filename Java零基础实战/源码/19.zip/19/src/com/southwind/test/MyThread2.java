package com.southwind.test;

public class MyThread2 extends Thread {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<1000;i++) {
			System.out.println("MyTrhead2++++++++++++++");
		}
	}
	
}
