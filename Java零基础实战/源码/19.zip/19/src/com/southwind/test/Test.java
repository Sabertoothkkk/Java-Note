package com.southwind.test;

public class Test {
	public static void main(String[] args) {
		//开启两个子线程
		MyThread thread1 = new MyThread();
		MyThread2 thread2 = new MyThread2();
		thread1.start();
		thread2.start();
		//实例化Runnable
		MyRunnable runnable = new MyRunnable();
		Thread thread = new Thread(runnable);
		thread.start();
		MyRunnable2 runnable2 = new MyRunnable2();
		Thread thread3 = new Thread(runnable2);
		thread3.start();
	}
}
