package com.southwind.interrupted;

public class Test {
	public static void main(String[] args) {
		Thread thread = new Thread();
		System.out.println(thread.getState());
		thread.interrupt();
		System.out.println(thread.isInterrupted());
	}
}
