package com.southwind.interrupted;

public class Test2 {
	public static void main(String[] args) {
//		MyRunnable runnable = new MyRunnable();
//		Thread thread = new Thread(runnable);
//		thread.start();
		
		Thread thread = new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				for(int i = 0; i < 10;i++) {
					System.out.println(i+"---main");
				}
			}
		});
		thread.start();
		System.out.println(thread.getState());
		thread.interrupt();
		System.out.println(thread.isInterrupted());
		System.out.println(thread.getState());
	}
}
