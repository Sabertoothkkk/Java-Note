package com.southwind.test;

public class JoinRunnable implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<200;i++) {
			System.out.println(i+"------JoinRunnable");
		}
	}

}
