package com.southwind.test;

public class Test {
	public static void main(String[] args) {
//		MyThread thread = new MyThread();
//		thread.start();
		MyThread2 thread = new MyThread2();
		thread.start();
		try {
			thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
