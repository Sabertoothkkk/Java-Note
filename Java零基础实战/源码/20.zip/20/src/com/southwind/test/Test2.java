package com.southwind.test;

public class Test2 {
	public static void main(String[] args) {
		for(int i=0;i<10;i++) {
			if(i == 5) {
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println(i+"+++++Test2+++++");
		}
	}
}
