package com.southwind.yield;

public class Test {
	public static void main(String[] args) {
		YieldThread1 thread = new YieldThread1();
		thread.setName("线程1");
		YieldThread2 thread2 = new YieldThread2();
		thread2.setName("线程2");
		thread.start();
		thread2.start();
	}
}
