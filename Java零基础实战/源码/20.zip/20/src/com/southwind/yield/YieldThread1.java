package com.southwind.yield;

public class YieldThread1 extends Thread {
	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i = 0; i < 10;i++) {
			if(i == 5) {
				yield();
			}
			System.out.println(Thread.currentThread().getName()+"-----"+i);
		}
	}
}
