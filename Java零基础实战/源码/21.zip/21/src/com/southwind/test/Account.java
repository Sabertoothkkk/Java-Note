package com.southwind.test;

public class Account implements Runnable {

	private static int num;
	
	@Override
	public synchronized void run() {
		// TODO Auto-generated method stub
		//1.num++操作
		num++;
		//2.休眠1毫秒
		try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//3.打印输出
		System.out.println(Thread.currentThread().getName()+"是当前的第"+num+"位访问");
	}
	
}
