package com.southwind.test;

public class SynchronizedTest {
	
	public static void main(String[] args) {
		for(int i = 0; i < 5;i++) {
			Thread thread = new Thread(new Runnable() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					SynchronizedTest.test();
				}
			});
			thread.start();
		}
	}
	
	/**
	 * 先输出start...
	 * 间隔1s
	 * 再输出end...
	 * 输出start...
	 * ...
	 */
	public synchronized static void test() {
		//1.输出start
		System.out.println("start......");
		//2.休眠
		try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//3.输出end
		System.out.println("end......");
	}
	
}
