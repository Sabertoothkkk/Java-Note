package com.southwind.test;

public class SynchronizedTest2 {
	public static void main(String[] args) {
		for(int i=0;i<5;i++) {
			Thread thread = new Thread(new Runnable() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					SynchronizedTest2 synchronizedTest2 = new SynchronizedTest2();
					synchronizedTest2.test();
				}
			});
			thread.start();
		}
	}
	
	public synchronized void test() {
		System.out.println("start......");
		try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("end......");
	}
}
