package com.southwind.test;

public class SynchronizedTest3 {
	
	public static void main(String[] args) {
		for(int i=0;i<5;i++) {
			Thread thread = new Thread(new Runnable() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					SynchronizedTest3 synchronizedTest3 = new SynchronizedTest3();
					synchronizedTest3.test();
				}
			});
			thread.start();
		}
	}
	
	public void test() {
		synchronized (SynchronizedTest3.class) {
			System.out.println("start...");
			try {
				Thread.currentThread().sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("end...");
		}
		
	}

}
