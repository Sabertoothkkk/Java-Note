package com.southwind.test;

public class Test {
	public static void main(String[] args) {
		Account account = new Account();
		Thread t1 = new Thread(account,"张三");
		Thread t2 = new Thread(account,"李四");
		t1.start();
		t2.start();
		for(int i = 0; i<10;i++) {
			Thread thread = new Thread(account,"线程"+i);
			thread.start();
		}
	}
}
