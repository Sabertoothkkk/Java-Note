package com.southwind.test;

public class Test {
	public static void main(String[] args) {
//		SingletonDemo singletonDemo = SingletonDemo.getInstance();
//		SingletonDemo singletonDemo2 = SingletonDemo.getInstance();
//		SingletonDemo singletonDemo3 = SingletonDemo.getInstance();
//		System.out.println(singletonDemo == singletonDemo2);
//		System.out.println(singletonDemo2 == singletonDemo3);
		for(int i=0;i<100;i++) {
			SingletonDemo singletonDemo = SingletonDemo.getInstance();
		}
	}
}
