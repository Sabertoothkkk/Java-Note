package com.southwind.test;

public class Test2 {
	public static void main(String[] args) {

		
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				SingletonDemo singletonDemo = SingletonDemo.getInstance();
			}
		}).start();
		
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				SingletonDemo singletonDemo = SingletonDemo.getInstance();
			}
		}).start();
	}
}
