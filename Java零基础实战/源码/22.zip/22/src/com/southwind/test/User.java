package com.southwind.test;

public class User {

}
