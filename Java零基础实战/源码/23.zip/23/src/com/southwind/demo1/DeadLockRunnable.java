package com.southwind.demo1;

public class DeadLockRunnable implements Runnable {
	//编号
	public int num;
	//资源
	private static Chopsticks chopsticks1 = new Chopsticks();
	private static Chopsticks chopsticks2 = new Chopsticks();
	
	/**
	 * num = 1 拿到 chopsticks1，等待 chopsticks2
	 * num = 2 拿到 chopsticks2，等待 chopsticks1
	 */
	@Override
	public void run() {
		// TODO Auto-generated method stub
		if(num == 1) {
			System.out.println(Thread.currentThread().getName()+"拿到了chopsticks1，等待获取chopsticks2");
			synchronized (chopsticks1) {
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				synchronized (chopsticks2) {
					System.out.println(Thread.currentThread().getName()+"用餐完毕！");
				}
			}
		}
		if(num == 2) {
			System.out.println(Thread.currentThread().getName()+"拿到了chopsticks2，等待获取chopsticks1");
			synchronized (chopsticks2) {
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				synchronized (chopsticks1) {
					System.out.println(Thread.currentThread().getName()+"用餐完毕！");
				}
			}
		}
	}

}
