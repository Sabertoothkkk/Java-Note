package com.southwind.demo2;

public class Test2 {
	public static void main(String[] args) {
		Thread thread = new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				for(int i=0;i<100;i++) {
					System.out.println("+++++++++++Runnable");
				}
			}
		});
		thread.start();
	}
}
