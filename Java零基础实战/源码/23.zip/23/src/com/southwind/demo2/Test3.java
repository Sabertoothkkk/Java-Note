package com.southwind.demo2;

public class Test3 {
	public static void main(String[] args) {
		new Thread(()->{for(int i=0;i<100;i++) System.out.println("+++++++Runnable");}).start();
		new Thread(()->{for(int i=0;i<100;i++) System.out.println("----Runnable");}).start();
		new Thread(()->{for(int i=0;i<100;i++) System.out.println("++++=====++Runnable");}).start();
	}
}
