package com.southwind.demo3;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Test2 {
	public static void main(String[] args) {
		Account account = new Account();
		new Thread(()->{
			account.count();
		},"A").start(); 
		new Thread(()->{
			account.count();
		},"B").start(); 
	}
}

class Account {
	private int num;
	private Lock lock = new ReentrantLock();

	public void count() {
		lock.lock();
		num++;
		System.out.println(Thread.currentThread().getName()+"是第"+num+"位访客");
		lock.unlock();
	}
	
}