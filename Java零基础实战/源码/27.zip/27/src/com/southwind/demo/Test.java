package com.southwind.demo;

import java.util.concurrent.TimeUnit;

public class Test {
    public static void main(String[] args) {
        Ticket ticket = new Ticket();
        new Thread(()->{
            for (int i = 0; i < 40; i++) {
                ticket.sale();
            }
        },"A").start();
        new Thread(()->{
            for (int i = 0; i < 40; i++) {
                ticket.sale();
            }
        },"B").start();
    }
}

class Ticket{
    private Integer saleNum = 0;
    private Integer lastNum = 30;

    public synchronized void sale(){
        if(lastNum > 0){
            saleNum++;
            lastNum--;
            try {
                TimeUnit.MILLISECONDS.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(Thread.currentThread().getName()+"卖出了第"+saleNum+"张票，剩余"+lastNum+"张票");
        }
    }

}