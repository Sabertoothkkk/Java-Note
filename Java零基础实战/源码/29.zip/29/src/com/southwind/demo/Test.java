package com.southwind.demo;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Test {
    public static void main(String[] args) {
        //单例线程池
//        ExecutorService executorService = Executors.newSingleThreadExecutor();
        //数量固定线程池
//        ExecutorService executorService = Executors.newFixedThreadPool(5);
        //缓存线程池，线程池的线程实例数量随机，由电脑的配置决定
        ExecutorService executorService = Executors.newCachedThreadPool();

        for (int i = 0; i < 10; i++) {
            final int temp = i;
            executorService.execute(()->{
                System.out.println(Thread.currentThread().getName()+":"+temp);
            });
        }

        executorService.shutdown();
    }
}

