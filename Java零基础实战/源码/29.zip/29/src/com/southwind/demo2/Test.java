package com.southwind.demo2;

import java.util.concurrent.*;

public class Test {
    public static void main(String[] args) {
        ExecutorService executorService = null;
        try {
            /**
             * 自己写7大参数，完全定制化
             */
            executorService = new ThreadPoolExecutor(
                    2,
                    3,
                    1L,
                    TimeUnit.SECONDS,
                    new ArrayBlockingQueue<>(2),
                    Executors.defaultThreadFactory(),
                    new ThreadPoolExecutor.DiscardOldestPolicy()
            );

            for (int i = 0; i < 6; i++) {
                executorService.execute(()->{
                    try {
                        TimeUnit.MILLISECONDS.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println(Thread.currentThread().getName()+"===>办理业务");
                });
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            executorService.shutdown();
        }
    }
}
