package com.southwind.demo;

public class Test2 {
    public static void main(String[] args) {
        Long sum = 0L;
        Long startTime = System.currentTimeMillis();
        for (Long i = 0L; i <=100_0000_0000L; i++) {
            sum += i;
        }
        Long endTime = System.currentTimeMillis();
        System.out.println(sum+"，共耗时"+(endTime-startTime));
    }
}
