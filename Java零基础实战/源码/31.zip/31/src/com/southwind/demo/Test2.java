package com.southwind.demo;

public class Test2 {
    public static void main(String[] args) {
        int d = f(10);
        System.out.println("d:"+d);
    }

    public static int f(int n){
        if(n == 1){
            System.out.println("m:"+n);
            return 1;
        }else{
            System.out.println("n:"+n);
            //n=4
            int c = f(n-1)+1;
            System.out.println("c:"+c);
            return c;
        }
    }
}
