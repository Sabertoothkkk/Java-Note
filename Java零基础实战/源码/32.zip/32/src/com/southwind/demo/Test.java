package com.southwind.demo;

import java.util.Vector;

public class Test {
    public static void main(String[] args) {
        //创建vector对象
        String str = "1";
        int num = 1;
        System.out.println(String.valueOf(num));
    }
}
