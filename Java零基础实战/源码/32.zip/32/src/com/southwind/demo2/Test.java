package com.southwind.demo2;

import java.util.ArrayList;
import java.util.Vector;
import java.util.concurrent.TimeUnit;

public class Test {
    static Vector list = new Vector();
    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
//            list.add(String.valueOf(i));
//            System.out.println(list);
            final int temp = i;
            new Thread(()->{
                try {
                    TimeUnit.MILLISECONDS.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                list.add(String.valueOf(temp));
                System.out.println(list);
            }).start();

        }
    }
}
