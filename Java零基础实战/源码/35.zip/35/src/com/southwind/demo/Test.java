package com.southwind.demo;

import entity.A;
import entity.Student;
import entity.User;

import java.util.ArrayList;
import java.util.Collections;

public class Test {
    public static void main(String[] args) {
        ArrayList arrayList = new ArrayList();
        arrayList.add("Hello");
        arrayList.add("World");
        System.out.println("添加之前的集合："+arrayList);
        int[] array = {1,2,3};
        boolean flag = Collections.addAll(arrayList,"JavaSE","JavaME","JavaEE");
        System.out.println("添加之后的集合："+arrayList);
        Collections.reverse(arrayList);
        System.out.println("反转之后的集合："+arrayList);
        Collections.swap(arrayList,1,4);
        System.out.println("调换位置之后的集合："+arrayList);
    }


    public static void test(int[] arg){

    }

}
