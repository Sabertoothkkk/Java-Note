package com.southwind.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

public class Test2 {
    public static void main(String[] args) {
//        ArrayList arrayList = new ArrayList();
//        arrayList.add("Hello");
//        arrayList.add("World");
//        Collections.addAll(arrayList,"Java","JavaSE","JavaME");
//        System.out.println(arrayList);

//        HashSet hashSet = new HashSet();
//        hashSet.add("Hello");
//        hashSet.add("World");
//        Collections.addAll(hashSet,"Java","JavaSE","JavaME");
//        System.out.println(hashSet);

//        ArrayList arrayList = new ArrayList();
//        arrayList.add("Hello");
//        arrayList.add("World");
//        Collections.reverse(arrayList);
//        System.out.println(arrayList);

        HashSet hashSet = new HashSet();
        hashSet.add("Hello");
        hashSet.add("World");
//        Collections.reverse(hashSet);
//        Collections.swap(hashSet,1,1);

    }
}
