package entity;

public class A {
}
