package entity;

public class Student {
}
