package entity;

public class User {
    @Override
    public String toString() {
        return "这是一个用户对象";
    }
}
