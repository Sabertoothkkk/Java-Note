package com.southwind.demo6;

import java.awt.font.NumericShaper;

public class Time<T> {

    public static void main(String[] args) {
        test(new Time<Float>());
        test(new Time<Integer>());
        test(new Time<Number>());

        test2(new Time<String>());
        test2(new Time<Object>());
    }

    /**
     * 泛型上限
     * @param time
     */
    public static void test(Time<? extends Number> time){

    }

    /**
     * 泛型下限
     * @param time
     */
    public static void test2(Time<? super String> time) {

    }

}
