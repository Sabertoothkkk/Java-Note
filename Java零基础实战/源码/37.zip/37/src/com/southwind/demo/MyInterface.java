package com.southwind.demo;

public interface MyInterface<T> {
    public T getValue();
}
