package com.southwind.demo;

public class Test {
    public static void main(String[] args) {
        MyInterfaceImpl myInterface = new MyInterfaceImpl<String>("接口");
        String val = (String) myInterface.getValue();

        MyInterfaceImpl2 myInterface1 = new MyInterfaceImpl2("接口");
        val = myInterface1.getValue();
    }
}
