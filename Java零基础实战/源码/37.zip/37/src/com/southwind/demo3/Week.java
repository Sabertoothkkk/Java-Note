package com.southwind.demo3;

public enum Week {
    MONDAY,
    FRIDAY,
    TUESDAY,
    WEDNSDAY,
    THURSDAY,
    SATURDAY,
    SUNDAY;
}
