package com.southwind.demo;

import javax.swing.*;

public class Test {
    public static void main(String[] args) {
//        String str1 = "Hello";
//        String str2 = "Hello";
//        System.out.println(str1 == str2);
//        String str3 = new String("World");
//        String str4 = new String("World");
//        System.out.println(str3 == str4);
//        System.out.println(str1.equals(str2));
//        System.out.println(str3.equals(str4));

        String str1 = "HELLO";
        System.out.println(str1.toLowerCase());
        String str2 = "hello";
        //左开右闭（可以取到左边，但是取不到右边）
        System.out.println(str1.replaceAll("o","a"));

        String str = "Hello,World,Java";
        String[] array = str.split(",");
//        int i = 0;

        char[] chars = str1.toCharArray();
        byte[] bytes = str1.getBytes();
        int i = 0;
    }
}
