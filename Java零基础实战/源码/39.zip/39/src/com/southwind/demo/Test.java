package com.southwind.demo;

public class Test {
    public static void main(String[] args) {
        StringBuffer stringBuffer = new StringBuffer("Hello");
        StringBuffer stringBuffer1 = new StringBuffer();
        //stringBuffer 底层数组的长度是 21
        //stringBuffer1 底层数组的长度是 16
        stringBuffer = stringBuffer.append("WorldJavaJavaSE");
        System.out.println(stringBuffer);
        stringBuffer = stringBuffer.delete(3,6);
        System.out.println(stringBuffer);
        stringBuffer = stringBuffer.deleteCharAt(3);
        System.out.println(stringBuffer);
        stringBuffer = stringBuffer.replace(3,6,"AAAAAA");
        System.out.println(stringBuffer);

//        System.out.println(stringBuffer.substring(3));
//        System.out.println(stringBuffer.substring(3,6));

//        String str1 = stringBuffer.substring(3);
//        System.out.println(str1);
//        String str2 = stringBuffer.substring(3,6);
//        System.out.println(str2);

        stringBuffer.insert(1,true);
        System.out.println(stringBuffer);

        System.out.println(stringBuffer.indexOf("A",10));
        stringBuffer.reverse();
        System.out.println(stringBuffer);

        String str = stringBuffer.toString();
        System.out.println(str);
    }
}
