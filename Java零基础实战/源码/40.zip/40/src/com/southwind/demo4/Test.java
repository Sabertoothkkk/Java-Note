package com.southwind.demo4;

import java.io.File;
import java.io.IOException;

public class Test {
    public static void main(String[] args) {
//        File file = new File("/Users/southwind/Desktop/test.txt");
//        System.out.println(file.exists());
//        System.out.println(file.getName());
        //byte为单位 1 byte = 8 位二进制数
        //Java 4 byte J 01010101 a 11110000 v 11110000 a 10101111
        //1 byte
        //1 KB = 1024 byte
        //1 MB = 1024 KB
        //1 GB = 1024 MB
        //1 TG = 1024 GB
//        System.out.println(file.length());
//        System.out.println(file.getPath());
//        File parent = new File(file.getParent());
//        System.out.println(parent.exists());
//        System.out.println(file.isFile());
//        System.out.println(parent.isFile());
//
//        System.out.println(file.isDirectory());
//        System.out.println(parent.isDirectory());
        System.out.println("**********************************");

        File file2 = new File("/Users/southwind/Desktop/test3.txt");

//        System.out.println(file2.exists());
//        try {
//            System.out.println(file2.createNewFile());
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

//        File file3 = new File("/Users/southwind/Desktop/test3.txt");
//        file2.renameTo(file3);

        System.out.println(file2.delete());
    }
}
