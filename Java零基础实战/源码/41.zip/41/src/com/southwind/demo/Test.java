package com.southwind.demo;

import java.io.File;

public class Test {
    public static void main(String[] args) {
        File file = new File("/Users/southwind/MyProjects/41/src/hello.txt");
        System.out.println(file.exists());
    }
}
