package com.southwind.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class Test2 {
    public static void main(String[] args) throws Exception {
        //file这个对象是用来映射桌面的test2.txt文件的
        File file = new File("/Users/southwind/Desktop/test2.txt");
        if(file.exists()){
            InputStream inputStream = new FileInputStream(file);

//            long length = file.length();
//            for (int i = 0; i < length; i++) {
//                System.out.println(inputStream.read());
//            }
//
//            System.out.println(inputStream.read());

//            int temp = 0;
//            while((temp = inputStream.read()) != -1 ){
//                System.out.println("当前读取到到的数据是"+temp+",当前未读取的数据个数是"+inputStream.available());
//            }

        }
    }
}
