package com.southwind.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class Test3 {
    public static void main(String[] args) throws Exception {
        File file = new File("/Users/southwind/Desktop/test2.txt");
        if(file.exists()){
            //1、创建数组
            byte bytes[] = new byte[100];
            //2、创建流
            InputStream inputStream = new FileInputStream(file);
            //3、读取流
            int length = inputStream.read(bytes,10,20);
            System.out.println(length);
        }

    }
}
