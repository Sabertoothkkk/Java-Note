package com.southwind.demo;

public class Test4 {
    public static void main(String[] args) {
        boolean[] array = new boolean[10];
        for (int i = 0; i < array.length; i++) {
            System.out.println(array[i]);
        }
    }
}
