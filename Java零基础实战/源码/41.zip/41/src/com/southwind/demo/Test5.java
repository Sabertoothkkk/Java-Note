package com.southwind.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class Test5 {
    public static void main(String[] args) throws Exception {
        File file = new File("/Users/southwind/Desktop/test2.txt");
        if(file.exists()){
            InputStream inputStream = new FileInputStream(file);
            byte[] bytes = inputStream.readAllBytes();
            int i = 0;
            inputStream.close();
        }
    }
}
