package com.southwind.demo2;

import java.io.FileOutputStream;
import java.io.OutputStream;

public class Test {
    public static void main(String[] args) throws Exception{
        OutputStream outputStream = new FileOutputStream("/Users/southwind/Desktop/target.txt");
        byte bytes[] = {105,111,99,100,98,66,78,90};
        outputStream.write(bytes,3,3);
        outputStream.flush();
        outputStream.close();
    }
}
