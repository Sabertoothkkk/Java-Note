package com.southwind.exception;

public class MyException extends RuntimeException {
    public MyException(String msg) {
        super(msg);
    }
}
