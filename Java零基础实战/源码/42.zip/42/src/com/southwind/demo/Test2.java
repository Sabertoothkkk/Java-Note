package com.southwind.demo;

import java.io.FileReader;
import java.io.Reader;

public class Test2 {
    public static void main(String[] args) throws Exception {
//        Reader reader = new FileReader("/Users/southwind/Desktop/test.txt");
//        char[] chars = new char[8];
//        int length = reader.read(chars);
//        System.out.println("数据流的长度是"+length);
//        System.out.println("遍历数组");
//        for (char aChar : chars) {
//            System.out.println(aChar);
//        }

        Reader reader = new FileReader("/Users/southwind/Desktop/test.txt");
        char[] chars = new char[8];
        //offset
        int length = reader.read(chars,2,3);
        System.out.println("数据流的长度是"+length);
        System.out.println("遍历数组");
        for (char aChar : chars) {
            System.out.println(aChar);
        }

    }
}
