package com.southwind.demo2;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.OutputStream;
import java.io.Writer;

public class Test {
    public static void main(String[] args) throws Exception {
        Writer writer = new FileWriter("/Users/southwind/Desktop/copy.txt");
        //writer.write("你好");
//        char[] chars = {'你','好','世','界'};
//        writer.write(chars,2,2);
        String str = "Hello World,你好世界";
        writer.write(str,10,6);
        writer.flush();
        writer.close();
    }
}
