package com.southwind.demo3;

        import java.io.FileOutputStream;
        import java.io.OutputStream;
        import java.io.OutputStreamWriter;

public class Test2 {
    public static void main(String[] args) throws Exception {
        String str = "你好 世界";
        OutputStream outputStream = new FileOutputStream("/Users/southwind/Desktop/copy.txt");
        OutputStreamWriter writer = new OutputStreamWriter(outputStream);
        writer.write(str,2,1);
        //writer.flush();
        writer.close();
    }
}
