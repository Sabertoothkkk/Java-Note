package com.southwind.demo;

import java.io.FileReader;
import java.io.Reader;

public class Test3 {
    public static void main(String[] args) throws Exception {
        Reader reader = new FileReader("/Users/southwind/Desktop/test.txt");
        int temp = 0;
        int num = 0;
        System.out.println("***start***");
        while ((temp = reader.read())!=-1){
            num++;
            System.out.println(temp);
        }
        System.out.println("***end***,读取了"+num+"次");
        reader.close();
    }
}
