package com.southwind.demo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.Reader;

public class Test4 {
    public static void main(String[] args) throws Exception {
        Reader reader = new FileReader("/Users/southwind/Desktop/test.txt");
        BufferedReader bufferedReader = new BufferedReader(reader);
        char[] chars = new char[1024];
        int length = bufferedReader.read(chars);
        System.out.println(length);
        for (char aChar : chars) {
            System.out.println(aChar);
        }
        bufferedReader.close();
        reader.close();
    }
}
