package com.southwind.demo2;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class Test {
    public static void main(String[] args) throws Exception {
        OutputStream outputStream = new FileOutputStream("/Users/southwind/Desktop/test2.txt");
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(outputStream);
        String str = "由于在开发Oak语言时，尚且不存在运行字节码的硬件平台，所以为了在开发时可以对这种语言进行实验研究，他们就在已有的硬件和软件平台基础上，按照自己所指定的规范，用软件建设了一个运行平台，整个系统除了比C++更加简单之外，没有什么大的区别。";
        byte[] bytes = str.getBytes();
//        for (byte aByte : bytes) {
//            bufferedOutputStream.write(aByte);
//        }
        bufferedOutputStream.write(bytes,9,9);
        bufferedOutputStream.flush();
        bufferedOutputStream.close();
        outputStream.close();
    }
}
