package com.southwind.demo2;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.Writer;

public class Test2 {
    public static void main(String[] args) throws Exception {
        Writer writer = new FileWriter("/Users/southwind/Desktop/test2.txt");
        BufferedWriter bufferedWriter = new BufferedWriter(writer);
//        String str = "由于在开发语言时尚且不存在运行字节码的硬件平台，所以为了在开发时可以对这种语言进行实验研究，他们就在已有的硬件和软件平台基础上，按照自己所指定的规范，用软件建设了一个运行平台，整个系统除了比C++更加简单之外，没有什么大的区别。";
//        bufferedWriter.write(str,5,10);
        char[] chars = {'J','a','v','a'};
//        bufferedWriter.write(chars,2,1);
        bufferedWriter.write(22902);
        bufferedWriter.flush();
        bufferedWriter.close();
        writer.close();
    }
}
