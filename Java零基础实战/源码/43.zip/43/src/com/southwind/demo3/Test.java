package com.southwind.demo3;

import com.southwind.entity.User;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class Test {
    public static void main(String[] args) throws Exception {
        User user = new User(1,"张三",22);
        OutputStream outputStream = new FileOutputStream("/Users/southwind/Desktop/obj.txt");
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
        objectOutputStream.writeObject(user);
        objectOutputStream.flush();
        objectOutputStream.close();
        outputStream.close();
    }
}
