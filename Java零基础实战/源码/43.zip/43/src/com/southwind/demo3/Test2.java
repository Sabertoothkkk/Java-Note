package com.southwind.demo3;

import com.southwind.entity.User;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;

public class Test2 {
    public static void main(String[] args) throws Exception {
        InputStream inputStream = new FileInputStream("/Users/southwind/Desktop/obj.txt");
        ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
        User user = (User) objectInputStream.readObject();
        System.out.println(user);
        objectInputStream.close();
        inputStream.close();
    }
}
