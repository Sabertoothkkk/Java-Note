package com.southwind.demo;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class Test {
    public static void main(String[] args) throws Exception {
        //1、通过输入流将文件读入到 Java
        InputStream inputStream = new FileInputStream("/Users/southwind/Desktop/1.png");
        //2、通过输出流将文件从 Java 中写入到 myjava
        OutputStream outputStream = new FileOutputStream("/Users/southwind/myjava/1.png");
        int temp = 0;
        int num = 0;
        long start = System.currentTimeMillis();
        while((temp = inputStream.read())!=-1){
            num++;
            outputStream.write(temp);
        }
        long end = System.currentTimeMillis();
        System.out.println("传输完毕，共耗时"+(end-start));
        outputStream.flush();
        outputStream.close();
        inputStream.close();
    }
}
