package com.southwind.demo;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.io.Writer;

public class Test2 {
    public static void main(String[] args) throws Exception {
        Reader reader = new FileReader("/Users/southwind/Desktop/test.txt");
        Writer writer = new FileWriter("/Users/southwind/myjava/test.txt");
        int temp = 0;
        int num = 0;
        while ((temp = reader.read())!=-1){
            writer.write(temp);
            num++;
        }
        System.out.println("传输完毕，共读取了"+num+"次");
        writer.flush();
        writer.close();
        reader.close();
    }
}
