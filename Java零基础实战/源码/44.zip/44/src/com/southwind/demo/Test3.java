package com.southwind.demo;

import java.io.*;

public class Test3 {
    public static void main(String[] args) throws Exception {
        Reader reader = new FileReader("/Users/southwind/Desktop/test.txt");
        BufferedReader bufferedReader = new BufferedReader(reader);

        Writer writer = new FileWriter("/Users/southwind/myjava/test.txt");
        BufferedWriter bufferedWriter = new BufferedWriter(writer);

        String str = "";
        int num = 0;
        while ((str = bufferedReader.readLine())!=null){
            bufferedWriter.write(str);
            num++;
        }

        System.out.println("传输完毕，共读取了"+num+"次");
        bufferedWriter.flush();
        bufferedWriter.close();
        writer.close();
        bufferedReader.close();
        reader.close();

    }
}
