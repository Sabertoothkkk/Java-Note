package com.southwind.demo;

import java.io.*;

public class Test4 {
    public static void main(String[] args) throws Exception {
        Reader reader = new FileReader("/Users/southwind/Desktop/1.png");
        BufferedReader bufferedReader = new BufferedReader(reader);

        Writer writer = new FileWriter("/Users/southwind/myjava/1.png");
        BufferedWriter bufferedWriter = new BufferedWriter(writer);

        long start = System.currentTimeMillis();
        String str = "";
        while ((str = bufferedReader.readLine())!=null){
            bufferedWriter.write(str);
        }
        long end = System.currentTimeMillis();
        System.out.println("传输完毕，共耗时"+(end - start));

        bufferedWriter.flush();
        bufferedWriter.close();
        writer.close();
        bufferedReader.close();
        reader.close();
    }
}
