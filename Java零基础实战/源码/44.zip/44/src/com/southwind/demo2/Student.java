package com.southwind.demo2;

public class Student {
}
