package com.southwind.demo2;

public class Test {
    public static void main(String[] args) throws Exception {
        User user = new User();
        //1
        Class clazz = Class.forName("com.southwind.demo2.User");
        System.out.println(clazz.getName());
        System.out.println(clazz.getTypeName());
        System.out.println(clazz.getSuperclass().getName());
        Class[] array = clazz.getInterfaces();
        System.out.println("****************");
        for (Class aClass : array) {
            System.out.println(aClass);
        }
        System.out.println("---------------------");
        //2
        Class clazz2 = User.class;
        System.out.println(clazz2.getName());
        //3
        Class clazz3 = user.getClass();
        System.out.println(clazz3.getName());
    }
}
