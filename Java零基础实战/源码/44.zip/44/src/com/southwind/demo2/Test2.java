package com.southwind.demo2;

public class Test2 {
    public static void main(String[] args) {
        String str = "com.southwind.demo2.Student";
        System.out.println(getObj(str));
    }

    public static Object getObj(String name){
        try {
            Class clazz = Class.forName(name);
            return clazz.getConstructor().newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
