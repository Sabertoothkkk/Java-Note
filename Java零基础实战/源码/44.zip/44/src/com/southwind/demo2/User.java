package com.southwind.demo2;

import java.io.Serializable;

public class User implements Serializable,Comparable {
    private Integer id;
    private String name;

    @Override
    public int compareTo(Object o) {
        return 0;
    }
}
